import csv
from flask import Flask, redirect, render_template, request, session, url_for,send_from_directory
from flask_session import Session
import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
import uuid
import get_class as gs
import genarate_csv as gcsv
import datetime

app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

client = MongoClient('mongodb://localhost:27017/')
db = client['scrapit']
collection = db['user_data']

user_history=db["user_historyclr"]


def scrape_page(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    print("URL: " + url)
    r = requests.get(url, headers=headers)
    r.raise_for_status()  # Raise an exception for 4xx or 5xx HTTP status codes
    soup = BeautifulSoup(r.content, "html.parser")
    return soup

def get_data(content):
    class_contents = {}
    elements_with_class = content.find_all(class_=True)
    # Extract classes and subclasses
    for i in elements_with_class:
        class_name = ' '.join(i['class'])
        tagname = i.name
        if class_name not in class_contents:
            class_contents[class_name] = {'subclasses': {}}
        if tagname not in class_contents[class_name]['subclasses']:
            class_contents[class_name]['subclasses'][tagname] = []
        class_contents[class_name]['subclasses'][tagname].append(i.text.strip())
    return class_contents


# Function to save data to CSV file with unique name
def save_to_csv(data):
    filename = f'outputs/raw_data/output_{session["user_name"]}.csv'
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Class', 'Tag', 'Content'])
        for class_name, class_data in data.items():
            for tag_name, contents in class_data['subclasses'].items():
                for content in contents:
                    writer.writerow([class_name, tag_name, content])
    return filename


# Route for the homepage
@app.route('/')
def welcome():
    return render_template('login.html')

@app.route('/auth',methods=['POST','GET'])
def auth():
    username=request.form['username']
    password=request.form['password']
    auth_status=collection.count_documents({"username":username,"password":password})
    if auth_status==1:
        session["user_name"]=username
        return render_template("search_url.html")
    else:
        return render_template("login.html",msg="Invalid Credentials !")

@app.route('/registration',methods=['POST','GET'])
def registration():
        return render_template("register.html")

@app.route('/create_account',methods=['POST','GET'])
def create_account():
    username = request.form['username']
    password=request.form['password']
    exist_status = collection.count_documents({"username": username})
    if exist_status>=1:
        return render_template("register.html",msg="Username Exist !")
    else:
        collection.insert_one({"username":username,"password":password})
        return render_template("register.html", msg="Account Created !")


@app.route('/scrap', methods=['POST'])
def scrape():
    if request.method == 'POST':
        url = request.form['url']
        time_stamp=datetime.datetime.now()
        user_history.insert_one({"username":session["user_name"],"url":url,"date_time":time_stamp})
        try:
            soup = scrape_page(url)
            data = get_data(soup)
            filename = save_to_csv(data)
            return render_template('search_string.html', url=url, class_contents=data, filename=filename)
        except requests.exceptions.RequestException as e:
            return f'Error occurred during request: {str(e)}'
        except Exception as e:
            return f'Error occurred: {str(e)}'
    return 'Method Not Allowed', 404


@app.route('/search_class', methods=['POST', 'GET'])
def search_class(): 
    search_string = request.form['search_string']
    filename = f'outputs/raw_data/output_{session["user_name"]}.csv'
    data = gs.run(search_string,filename)
    print(data)
    data_class = data['Class'].values
    data_tag = data['Tag'].values
    data_content = data['Content'].values
    data = {
        "Class":list(data_class),
        "Tag":list(data_tag),
        "Content":list(data_content)
    }
    data["length"]=len(data["Class"])
    return render_template("search_class.html", data=data)

@app.route('/generate_csv', methods=['POST', 'GET'])
def generate_csv():
    class_name=request.form['class_name']
    filter_filename = f'outputs/filtered_data/output_filter_{session["user_name"]}.csv'
    dir = "outputs/filtered_data"
    file=f'output_filter_{session["user_name"]}.csv'
    path_filename = f'outputs/raw_data/output_{session["user_name"]}.csv'
    gcsv.run(class_name,path_filename,filter_filename)
    return send_from_directory(directory=dir, path=file)

@app.route("/history")
def history():
    history_data=user_history.find({"username":session["user_name"]})
    return render_template("history.html",data=history_data)


@app.route('/logout', methods=['POST', 'GET'])
def logout():
    session.pop("user_name",None)
    return redirect("/")

@app.route('/download/raw_data')
def download_rawdata():
    filename = f'output_{session["user_name"]}.csv'
    dir="outputs/raw_data"
    return send_from_directory(directory=dir,path=filename)

@app.route('/scrap_web')
def scrap_web():
    return render_template("search_url.html")


if __name__ == '__main__':
    app.run()